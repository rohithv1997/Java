package spms;
public class SPMS {
   public static void main(String[] args) {
   Login login = new Login();
   
   login.setVisible(true);
   }
}
    

